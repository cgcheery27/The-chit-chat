# ChatRoom
Python based simple chatroom

## --Setting Up server--

python3 server.py IP PORT

## --Using Client--

 python3 client.py IP PORT

 --------
 
 IP : Server IP Address
 
 
 PORT : SERVER PORT 
